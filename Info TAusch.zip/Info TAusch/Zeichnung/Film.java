/**
 * Diese Klasse definiert eine einfache Zeichnung. Um die Zeichnung auf
 * dem Bildschirm anzeigen zu lassen, muss die zeichne-Operation auf
 * einem Exemplar aufgerufen werden.
 * Aber hier steckt mehr drin: Da es eine elektronische Zeichnung ist,
 * kann sie ge�ndert werden. Man kann sie schwarz-wei� anzeigen lassen
 * und dann wieder in Farbe (nachdem sie gezeichnet wurde, ist ja klar).
 * 
 * Diese Klasse ist als fr�hes Java-Lehrbeispiel mit BlueJ gedacht.
 * 
 * @author  Michael K�lling und David J. Barnes
 * @changes Felix Mertins
 * @version 2.0  (3. September 2020)
 */
public class Film
{
   //Objektdeklaration
   
   private Quadrat wand;
   private Quadrat fenster;
   private Dreieck dach;
   private Kreis sonne;
   private Rechteck tuer;
   private Oval wolke1;
   private Oval wolke2;
   private Oval tropfen1;
   private int animation;
   private Kreis mond;
   /**
   * Attributmodifikation der verschiedenen Objekte im Bezug auf Farbe, Position und Gr��e
   */
   public Film()
   {
        // Angaben f�r die Zeichnung
        
    	wand = new Quadrat();
        wand.vertikalBewegen(80);
        wand.groesseAendern(100);

        fenster = new Quadrat();
        fenster.farbeAendern("gelb");
        fenster.horizontalBewegen(20);
        fenster.vertikalBewegen(100);

        dach = new Dreieck();  
        dach.groesseAendern(50, 140);
        dach.horizontalBewegen(60);
        dach.vertikalBewegen(70);
        dach.farbeAendern("rot");
        
        sonne = new Kreis();
        sonne.farbeAendern("gelb");
        sonne.horizontalBewegen(180);
        sonne.vertikalBewegen(-10);
        sonne.groesseAendern(60);
        
        tuer = new Rechteck();
        tuer.farbeAendern("gelb");
        tuer.horizontalBewegen(60);
        tuer.vertikalBewegen(120);
        
        wolke1 = new Oval();
        wolke1.vertikalBewegen(-10);
        wolke1.YgroesseAendern(30);
        wolke1.XgroesseAendern(75);
        wolke1.horizontalBewegen(100);
        wolke1.farbeAendern("blau");
        
        wolke2 = new Oval();
        wolke2.vertikalBewegen(-10);
        wolke2.YgroesseAendern(20);
        wolke2.XgroesseAendern(50);
        wolke2.horizontalBewegen(50);
        wolke2.farbeAendern("blau");
        
        tropfen1 = new Oval();
        tropfen1.horizontalBewegen(50);
        tropfen1.vertikalBewegen(-10);
        tropfen1.YgroesseAendern(20);
        tropfen1.XgroesseAendern(10);
        
        mond = new Kreis();
        mond.farbeAendern("blau");
        mond.groesseAendern(60);
        mond.vertikalBewegen(150);
        mond.horizontalBewegen(30);
   }
   
   /**
    * Zeichnen der Zeichnung.
   */
   public void zeichne()
   {
        //Zeichnen der einzelnen Objekte
        
        wand.sichtbarMachen();
        fenster.sichtbarMachen();
        dach.sichtbarMachen();
        sonne.sichtbarMachen();
        tuer.sichtbarMachen();
        wolke1.sichtbarMachen();
        wolke2.sichtbarMachen();
   }

   /**
   * �ndere die Darstellung in schwarz-wei�.
   */
   public void inSchwarzWeissAendern()
   {
        if(wand != null)   // �berpr�fung ob die Zeichnung schon gezeichnet wurde.
        {
           wand.farbeAendern("schwarz");
           fenster.farbeAendern("weiss");
           dach.farbeAendern("schwarz");
           sonne.farbeAendern("schwarz");
           tuer.farbeAendern("weiss");
           wolke1.farbeAendern("schwarz");
           wolke2.farbeAendern("schwarz");
           tropfen1.farbeAendern("schwarz");
           mond.farbeAendern("schwarz");
        }
        else
        {
            this.zeichne();
           wand.farbeAendern("schwarz");
           fenster.farbeAendern("weiss");
           dach.farbeAendern("schwarz");
           sonne.farbeAendern("schwarz");
           tuer.farbeAendern("weiss");
           wolke1.farbeAendern("schwarz");
           wolke2.farbeAendern("schwarz");
           tropfen1.farbeAendern("schwarz");
           mond.farbeAendern("schwarz");
        }
   }

   /**
   * �ndere die Darstellung in Farbe.
   */
   public void inFarbeAendern()
   {
        if(wand != null)   // �berpr�fung ob die Zeichnung schon gezeichnet wurde.
        {
            wand.farbeAendern("rot");
            fenster.farbeAendern("gelb");
            dach.farbeAendern("gruen");
            sonne.farbeAendern("gelb");
            tuer.farbeAendern("gelb");
            wolke1.farbeAendern("blau");
            wolke2.farbeAendern("blau");
            tropfen1.farbeAendern("blau");
            mond.farbeAendern("blau");
        }
        else
        {
            this.zeichne();
            wand.farbeAendern("rot");
            fenster.farbeAendern("gelb");
            dach.farbeAendern("gruen");
            sonne.farbeAendern("gelb");
            tuer.farbeAendern("gelb");
            wolke1.farbeAendern("blau");
            wolke2.farbeAendern("blau");
            tropfen1.farbeAendern("blau");
            mond.farbeAendern("blau");
        }
   }
   
   public void sonnenUntergang()
   {   
       if(wand != null)
       {
           mond.xSetzen(50);
           mond.ySetzen(210);
           mond.sichtbarMachen();
           for(int i=150;i>0;i--)
           {
               sonne.vertikalBewegen(1);
               sonne.horizontalBewegen(1);
               mond.vertikalBewegen(-1);
               mond.horizontalBewegen(1);
           }
           this.inSchwarzWeissAendern();
           sonne.unsichtbarMachen();
       }
       else
       {
           this.zeichne();
           mond.xSetzen(50);
           mond.ySetzen(210);
           mond.sichtbarMachen();
           for(int i=150;i>0;i--)
           {
               sonne.vertikalBewegen(1);
               sonne.horizontalBewegen(1);
               mond.vertikalBewegen(-1);
               mond.horizontalBewegen(1);
           }
           this.inSchwarzWeissAendern();
           sonne.unsichtbarMachen();
       }
   }
   public void sonnenAufgang()
   {   
       if(wand != null)
       {
           sonne.sichtbarMachen();
           sonne.horizontalBewegen(-300);
           this.inFarbeAendern();
           for(int i=150;i>0;i--)
           {
               sonne.vertikalBewegen(-1);
               sonne.horizontalBewegen(1);
               mond.vertikalBewegen(1);
               mond.horizontalBewegen(1);
           }
           mond.unsichtbarMachen();
       }
       else
       {
           this.zeichne();
           sonne.horizontalBewegen(-300);
           sonne.sichtbarMachen();
           this.inFarbeAendern();
           for(int i=150;i>0;i--)
           {
               sonne.vertikalBewegen(-1);
               sonne.horizontalBewegen(1);
               mond.vertikalBewegen(1);
               mond.horizontalBewegen(1);
           }
           mond.unsichtbarMachen();
       } 
   }
   public void regne()
   {
        if(wand != null)
        {
            animation =0;
            while(animation < 100)
            {
                tropfen1.langsamVertikalBewegen(150);
                tropfen1.unsichtbarMachen();
                tropfen1.vertikalBewegen(-150);
                tropfen1.sichtbarMachen();
                animation++ ;
            }
            tropfen1.unsichtbarMachen();
        }
        else
        {
            this.zeichne();
            animation =0;
            while(animation < 100)
            {
                tropfen1.langsamVertikalBewegen(150);
                tropfen1.unsichtbarMachen();
                tropfen1.vertikalBewegen(-150);
                tropfen1.sichtbarMachen();
                animation++ ;
            }
            tropfen1.unsichtbarMachen();
        }
   }
   public void film()
   {
       this.zeichne();
       
   }
}
