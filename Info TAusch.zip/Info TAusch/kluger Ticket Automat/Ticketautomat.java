import java.util.Scanner;

/**
 * 
 * ERKLÄRUNG DES AUTOMATEN 
 * 
 * Der kluge Ticketautomat modelliert den Versuch den "naiven Ticketautomat" 
 * zu verbessern.
 * 
 * Die Methoden "aktiviereKonsolenzugriff(String passwortEingabe)" und
 * "starteInteraktivenBetrieb()" sind interaktiv Aufgebaut.
 *
 * @author Felix Mertins
 * @version Alpha 1.0 Stable release
 */
public class Ticketautomat 
{
    // Der Preis eines Tickets dieses Automaten.
    private int preis;
    // Der Betrag, der bisher vom Automatenbenutzer eingeworfen wurde.
    private int bisherGezahlt;
    // Die Geldsumme, die bisher von diesem Automaten eingenommen wurde.
    private int gesamtsumme;
    //Die Summe an Papier die noch vorhanden ist.
    private int verfuegbarkeit;
    //Passwort für das Sicherheitssystem des Automaten
    private String passwort;
    //Zugriff für das Administrationsmenü
    private boolean aktiverZugriff;
    /**
     * Erzeuge eine Maschine, die Tickets zum angegebenen Preis
     * (in Cent) ausgibt.
     * Zu beachten: Der Preis muss größer als Null sein,
     * der Automat überprüft dies jedoch nicht.
     */
    public Ticketautomat(int ticketpreis, String neuesPasswort)
    {
        preis = ticketpreis;
        if(preis<=0)
        {
            System.out.println("Initiierung des Automaten Fehlgeschlagen!");
            System.out.println("Fehlercode: 1");
            System.out.println("Der Ticketpreis kann nicht kleiner oder");
            System.out.println("gleich null sein!");
            bisherGezahlt = 0;
            gesamtsumme = 0;
            verfuegbarkeit = 100;
            System.out.println("Bitte löschen sie dieses Obekt und");
            System.out.println("initiieren sie den Automaten neu!");
        }
        else
        {
            preis = ticketpreis;
            bisherGezahlt = 0;
            gesamtsumme = 0;
            verfuegbarkeit = 100;
        }
        passwort = neuesPasswort;
        aktiverZugriff = false;
    }

    /**
     * Aktiviert den Konsolenzugriff für die ganzen Veränderungsmethoden
     */
    public void aktiviereKonsolenZugriff(String passwortEingabe)
    {
        if(passwort == passwortEingabe)
        {
            System.out.println("");
            System.out.println("Konsolenzugriff");
            System.out.println("##################");
            System.out.println("Acces granted!");
            aktiverZugriff = true;
            while (aktiverZugriff == true)
            {
                System.out.println("");
                System.out.println("Bitte geben sie nun im Eingabefeld die gewünschte Option als Nummer ein!");
                System.out.println("Sie können aus folgenden Optionen wählen:");
                System.out.println("1 : Papierfüllstand überprüfen");
                System.out.println("2 : Papier nachfüllen");
                System.out.println("3 : Preis bearbeiten");
                System.out.println("4 : Verdientes Geld entnehmen");
                System.out.println("5 : Zugriff beenden");
                Scanner input = new Scanner(System.in);
                int option = input.nextInt();
                input.close();
                if(option == 1)
                {
                    System.out.println("Es sind noch "+verfuegbarkeit+" Tickets druckbar!");
                }
                else
                {
                    if(option == 2)
                    {
                        this.papierNachfüllen();
                    }
                    else
                    {
                        if(option == 3)
                        {
                            System.out.println("Bitte geben sie den neuen Preis ein!");
                            Scanner input1 = new Scanner(System.in);
                            int eingabe = input1.nextInt();
                            input.close();
                            this.preisAendern(eingabe);
                            System.out.println("Der Preis ist nun "+preis+" Cent");
                        }
                        else
                        {
                            if(option == 4)
                            {
                                this.gesamtesGeldEntnehmen();
                            }
                            else
                            {
                                if(option == 5)
                                {
                                    aktiverZugriff=false;
                                }
                                else
                                {
                                    System.out.println("Ungültige Option!");
                                }
                            }
                        }
                    } 
                }
            }
        }

        else
        {
            System.out.println("");
            System.out.println("Konsolenzugriff");
            System.out.println("##################");
            System.out.println("Acess denied!");
            System.out.println("Falsches Passwort");
            System.out.println("");
        }
    }

    /**
     * Liefert wie viele Tickets noch gedruckt werden können.
     */
    public int gibVerfuegbarkeit()
    {
        return verfuegbarkeit;
    }

    /**
     * Füllt das Papier nach.
     */
    public void papierNachfüllen()
    {
        verfuegbarkeit = 100;
    }

    /**
     * Liefere den Preis eines Tickets dieses Automaten (in Cent).
     */
    public int gibPreis()
    {
        return preis;
    }

    /**
     * Liefere die Höhe des Betrags, der für das nächste Ticket bereits
     * eingeworfen wurde.
     */
    public int gibBisherGezahltenBetrag()
    {
        return bisherGezahlt;
    }

    /**
     * Nimm den angegebenen Betrag (in Cent) als Anzahlung für das
     * nächste Ticket.
     */
    public void geldEinwerfen(int betrag)
    {
        if (betrag<=0)
        {
            System.out.println("Einwurf nicht möglich");
        }
        else
        {
            bisherGezahlt += betrag;
            System.out.println("Einwurf möglich");
            System.out.println("Es fehlen noch: "+(preis-bisherGezahlt)+"Cent.");
        }
    }

    /**
     * Druckt das Ticket.
     */
    public void ticketDrucken()
    {
        if(bisherGezahlt >= preis)
        {
            if(verfuegbarkeit<=0)
            {
                System.out.println("Ihr Ticket konnte nicht gedruckt werden,da");
                System.out.println("nicht ausreichend Papier vorhanden war.");
                System.out.println("Die eingeworfene Summe von "+bisherGezahlt+" Cent, wird ihnen zurueckerstattet.");
                System.out.println("Wir entschuldigen uns für die unannehmlichkeiten!");
                bisherGezahlt = 0;
            }
            else
            {
                // Den Ausdruck eines Tickets simulieren.
                System.out.println("##################");
                System.out.println("# Die BlueJ-Linie");
                System.out.println("# Ticket");
                System.out.println("# " + preis + " Cent.");
                System.out.println("##################");
                System.out.println();
                if(bisherGezahlt>preis)
                {
                    System.out.println("Sie erhalten "+ (bisherGezahlt-preis) + " Cent als Wechselgeld zurück");
                }
                // Die Gesamtsumme mit dem eingezahlten Betrag aktualisieren.
                gesamtsumme += preis;
                // Die bisherige Bezahlung zurücksetzen.
                bisherGezahlt = 0;
                //Die Verfuegbarkeit aktualisieren
                verfuegbarkeit --;
            }
        }
        else
        {
            System.out.println("Nicht genügend Geld eingeworfen!");
            System.out.println("Es fehlen noch " + (preis-bisherGezahlt) +" Cent!");
        }
    }
    
    public void zahlungAbbrechen()
    {
        System.out.println("Die Zahlung wurde erfolgreich abgebrochen und sie erhalten eine Summe von" + (preis-bisherGezahlt) +" Cent");
        bisherGezahlt = 0;
    }
    public void gesamtesGeldEntnehmen()
    {
        System.out.println("Sie haben einen Betrag von "+gesamtsumme+" Cent entnommen!");
        gesamtsumme = 0;
    }

    public void preisAendern(int neuerPreis)
    {
        preis = neuerPreis;
    }

}
