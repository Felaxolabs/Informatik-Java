
/**
 * Beschreiben Sie hier die Klasse Auto.
 * 
 * @author (I) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Auto1
{
    private Kreis hinterreifen1;
    private Kreis vorderreifen1;
    private Rechteck koerper1;
    private Quadrat vorderfenster1;
    private Rechteck hinterfenster1;
    //Variablen f�r die Bewegung
    private int XposHR1;
    private int XposVR1;
    private int XposK1;
    private int XposVF1;
    private int XposHF1;
    /**
     * Konstruktor f�r Objekte der Klasse Auto
     */
    public Auto1()
    {
        hinterreifen1 = new Kreis();
        hinterreifen1.xSetzen(40);
        hinterreifen1.ySetzen(280);
        hinterreifen1.farbeAendern("schwarz");
        
        vorderreifen1 = new Kreis();
        vorderreifen1.xSetzen(80);
        vorderreifen1.ySetzen(280);
        vorderreifen1.farbeAendern("schwarz");
        
        koerper1 = new Rechteck();
        koerper1.breiteAendern(75);
        koerper1.hoeheAendern(60);
        koerper1.xSetzen(40);
        koerper1.ySetzen(230);
        koerper1.farbeAendern("gruen");
        
        vorderfenster1 = new Quadrat();
        vorderfenster1.groesseAendern(30);
        vorderfenster1.xSetzen(80);
        vorderfenster1.ySetzen(235);
        vorderfenster1.farbeAendern("gelb");
        
        hinterfenster1 = new Rechteck();
        hinterfenster1.breiteAendern(20);
        hinterfenster1.hoeheAendern(20);
        hinterfenster1.xSetzen(45);
        hinterfenster1.ySetzen(235);
        hinterfenster1.farbeAendern("gelb");
        
        XposHR1 = 40;
        XposVR1 = 80;
        XposK1 = 40;
        XposVF1 = 80;
        XposHF1 = 45;
    }
    
    public void zeichneAuto1()
    {
        hinterreifen1.sichtbarMachen();
        vorderreifen1.sichtbarMachen();
        koerper1.sichtbarMachen();
        vorderfenster1.sichtbarMachen();
        hinterfenster1.sichtbarMachen();
    }
    
    public void auto1bewegen()
    {
        hinterreifen1.langsamHorizontalBewegen(1);
        vorderreifen1.langsamHorizontalBewegen(1);
        koerper1.langsamHorizontalBewegen(1);
        vorderfenster1.langsamHorizontalBewegen(1);
        hinterfenster1.langsamHorizontalBewegen(1);
    }

}
