
/**
 * Beschreiben Sie hier die Klasse Auto.
 * 
 * @author (I) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Auto2
{
    private Kreis hinterreifen2;
    private Kreis vorderreifen2;
    private Rechteck koerper2;
    private Quadrat vorderfenster2;
    private Rechteck hinterfenster2;
    //Variablen f�r die Bewegung
    private int XposHR2;
    private int XposVR2;
    private int XposK2;
    private int XposVF2;
    private int XposHF2;
    /**
     * Konstruktor f�r Objekte der Klasse Auto
     */
    public Auto2()
    {
        hinterreifen2 = new Kreis();
        hinterreifen2.xSetzen(240);
        hinterreifen2.ySetzen(280);
        hinterreifen2.farbeAendern("schwarz");

        vorderreifen2 = new Kreis();
        vorderreifen2.xSetzen(280);
        vorderreifen2.ySetzen(280);
        vorderreifen2.farbeAendern("schwarz");

        koerper2 = new Rechteck();
        koerper2.breiteAendern(75);
        koerper2.hoeheAendern(60);
        koerper2.xSetzen(240);
        koerper2.ySetzen(230);
        koerper2.farbeAendern("blau");

        vorderfenster2 = new Quadrat();
        vorderfenster2.groesseAendern(30);
        vorderfenster2.xSetzen(245);
        vorderfenster2.ySetzen(235);
        vorderfenster2.farbeAendern("gelb");

        hinterfenster2 = new Rechteck();
        hinterfenster2.breiteAendern(20);
        hinterfenster2.hoeheAendern(20);
        hinterfenster2.xSetzen(280);
        hinterfenster2.ySetzen(235);
        hinterfenster2.farbeAendern("gelb");

        XposHR2 = 240;
        XposVR2 = 280;
        XposK2 = 240;
        XposVF2 = 280;
        XposHF2 = 245;
    }

    public void zeichneAuto2()
    {
        hinterreifen2.sichtbarMachen();
        vorderreifen2.sichtbarMachen();
        koerper2.sichtbarMachen();
        vorderfenster2.sichtbarMachen();
        hinterfenster2.sichtbarMachen();
    }

    public void auto2bewegen()
    {
        hinterreifen2.langsamHorizontalBewegen(-1);
        vorderreifen2.langsamHorizontalBewegen(-1);
        koerper2.langsamHorizontalBewegen(-1);
        vorderfenster2.langsamHorizontalBewegen(-1);
        hinterfenster2.langsamHorizontalBewegen(-1);
    }

    public void autoHoch()
    {
        hinterreifen2.vertikalBewegen(-1);
        vorderreifen2.vertikalBewegen(-1);
        koerper2.vertikalBewegen(-1);
        vorderfenster2.vertikalBewegen(-1);
        hinterfenster2.vertikalBewegen(-1);
    }
    public void auto2SchnellBewegen()
    {
        hinterreifen2.langsamHorizontalBewegen(-3);
        vorderreifen2.langsamHorizontalBewegen(-3);
        koerper2.langsamHorizontalBewegen(-3);
        vorderfenster2.langsamHorizontalBewegen(-3);
        hinterfenster2.langsamHorizontalBewegen(-3);
    }
}
