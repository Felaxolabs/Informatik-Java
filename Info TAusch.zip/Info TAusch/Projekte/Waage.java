
/**
 * Beschreiben Sie hier die Klasse Waage.
 * 
 * @author (Felix Mertins) 
 * @version (1.4.3 Stable - 31.10.2020)
 */
public class Waage
{
    private double gewicht;
    private double groesse;
    private double bmi;
    private String geschlecht;
    /**
     * Konstruktor f�r Objekte der Klasse Bodyma�indexWaage
     * Gewicht in kg Groesse in m
     */
    public Waage(double neuesGewicht, double neueGroesse, String neuesGeschlecht)
    {
        gewicht = neuesGewicht;
        groesse = neueGroesse;
        if(neuesGeschlecht.equals("w") || neuesGeschlecht.equals("m") || neuesGeschlecht.equals("d"))
        {
            geschlecht = neuesGeschlecht;
        }
        else
        {
            System.out.println("Fehlerhafte Angabe des Geschlechts!");
            System.out.println("Bitte verwenden sie nur m, w oder d");
            geschlecht = "Error";
        }
    }
    /**
     * Alternativer Konstruktor f�r Objekte der Klasse Bodyma�indexWaage
     */
    // public Waage(String neuesGeschlecht)
    // {
    // gewicht = 0;
    // groesse = 0;
    // if(neuesGeschlecht.equals("w") || neuesGeschlecht.equals("m") || neuesGeschlecht.equals("d"))
        // {
            // geschlecht = neuesGeschlecht;
        // }
        // else
        // {
            // System.out.println("Fehlerhafte Angabe des Geschlechts!");
            // System.out.println("Bitte verwenden sie nur m, w oder d");
            // geschlecht = "Error";
        // }
    // }

    /**
     * Getter f�r Gewicht
     */
    public double gibGewicht()
    {
        return gewicht;
    }

    /**
     * Getter f�r Groesse
     */
    public double gibGroesse()
    {
        return groesse;
    }

    /**
     * Setter f�r Gewicht
     */
    public void setzeGewicht(double neuesGewicht)
    {
        gewicht = neuesGewicht;
    }

    /**
     * Setter f�r Groesse
     */
    public void setzeGroesse(double neueGroesse)
    {
        groesse = neueGroesse;
    }

    /**
     * Setter f�r Geschlecht mit (m w d)
     */
    public void setzeGeschlecht(String neuesGeschlecht)
    {
        if(neuesGeschlecht.equals("w") || neuesGeschlecht.equals("m") || neuesGeschlecht.equals("d"))
        {
            geschlecht = neuesGeschlecht;
        }
        else
        {
            System.out.println("Fehlerhafte Angabe des Geschlechts!");
            System.out.println("Bitte verwenden sie nur m, w oder d");
            geschlecht = "Error";
        }
    }

    /**
     * 
     */
    public String gibGeschlecht()
    {
        return geschlecht;
    }

    /**
     * Berechne bmi
     */
    public void berechneBMI()
    {
        if(groesse <= 0 || gewicht <= 0)
        {
            System.out.println("Ung�ltige Gewichts oder Groessenangaben!");
            System.out.println("Bitte versuchen sie es erneut!");
            bmi = -1; //BMI wird mit -1 initialisiert, da dieser Wert
            //nicht kommen kann. Wird in der Detailausgabe mit �berpr�fung
            //versehen!
        }
        else
        {
            bmi = (gewicht/(groesse*groesse));
        }
    }

    public void detailAusgabe()
    {
        System.out.println("############################################");
        System.out.println("###########Body-Ma�-Index Waage#############");
        System.out.println("#");
        System.out.println("############Ihre Informationen##############");
        System.out.println("#Geschlecht: " + geschlecht);
        System.out.println("#Groesse: " + groesse + "cm");
        System.out.println("#Gewicht: " + gewicht + "kg");
        this.berechneBMI();
        if(bmi == -1)
        {
            System.out.println("#BMI konnte aufgrund falscher Angaben nicht berechnet werden!");
        }
        else
        {
            System.out.println("#Body-Ma�-Index: " + bmi);
        }
        System.out.println("#");
        System.out.println("#################Details####################");
        if(geschlecht.equals("m"))
        {
            if(bmi<20 && bmi != -1)
            {
                System.out.println("#Sie sind Untergewichtig");
            }
            else if(bmi >= 20 && bmi < 25)
            {
                System.out.println("#Sie sind Normalgewichtig");
            }
            else if(bmi >= 25 && bmi < 30)
            {
                System.out.println("#Sie sind �bergewichtig ");
            }
            else if(bmi != -1)
            {
                System.out.println("#Sie sind in einer Adipositaklasse");
            }
            else
            {
                System.out.println("#Fehlerhafter BMI");
            }
        }
        else if(geschlecht.equals("w"))
        {
            if(bmi<19 && bmi != -1)
            {
                System.out.println("#Sie sind Untergewichtig");
            }
            else if(bmi >= 19 && bmi < 24)
            {
                System.out.println("#Sie sind Normalgewichtig");
            }
            else if(bmi >= 24 && bmi < 30)
            {
                System.out.println("#Sie sind �bergewichtig");
            }
            else if(bmi != -1)
            {
                System.out.println("#Sie sind in einer Adipositaklasse");
            }
            else
            {
                System.out.println("#Fehlerhafter BMI");
            }
        }
        else if(geschlecht.equals("d"))
        {
            System.out.println("#Wir k�nnen zu ihrem Geschlecht keine genauen Angaben machen!");
        }
        else
        {
            System.out.println("#Wir konnten ihnen aufgrund von dem Fehlerhaften geschlecht,");
            System.out.println("#keine Angaben machen!");
        }
        //Angaben nach https://bit.ly/2HMIGhA (Link gek�rzt)
        System.out.println("############################################");
    }
}