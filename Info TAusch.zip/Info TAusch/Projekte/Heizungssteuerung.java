
/**
 * Beschreiben Sie hier die Klasse Heizungssteuerung.
 * 
 * @author (Felix Mertins) 
 * @version (1.2.9 Stable - 1.11.2020)
 */
public class Heizungssteuerung
{
    private double temperatur;
    
    public Heizungssteuerung()
    {
        temperatur = 15.5;
    }
    
    public double gibTemperatur()
    {
        return temperatur;
    }
    
    public void waermer()
    {
        if(temperatur < 45)
        {
            temperatur += 0.5;
        }
        else
        {
            System.out.println("Temperatur kann nur zwischen 0 und 45 C� liegen!");
        }
    }
    
    public void kaelter()
    {
        if(temperatur > 0)
        {
            temperatur -= 0.5;
        }
        else
        {
            System.out.println("Temperatur kann nur zwischen 0 und 45 C� liegen!");
        }
    }
    
    public void schnellWaermer()
    {
        if(temperatur <= 40)
        {
            temperatur += 5;
        }
        else
        {
            System.out.println("Temperatur kann nur zwischen 0 und 45 C� liegen!");
        }
    }
    
    public void schnellKaelter()
    {
        if(temperatur >= 5)
        {
            temperatur -= 5;
        }
        else
        {
            System.out.println("Temperatur kann nur zwischen 0 und 45 C� liegen!");
        }
    }
    
    public void ausgabe()
    {
        int gerundet = (int) temperatur;
        System.out.println("Die Temperatur betraegt " + gerundet + "Grad Celsius");
        for (int i = 0; i <= temperatur; i++)
        {
            System.out.print("*");
        }
        System.out.println("0||||5||||10|||15|||20|||25|||30|||35");
    }
}