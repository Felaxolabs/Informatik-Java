/**
 * 
 * Bibliothekssoftware Der Bibleothekar (Java Edition)
 *
 * @author (Felix Mertins)
 * @version (Alpha 1.4.3 Stable - 28.10.2020)
 */
class Buch
{
    // Exemplarvariablen
    private String autor;
    private String titel;
    private int seiten;
    private String signatur;
    private int ausgeliehen;
    private int ausleihzeit;
    /**
     * Setze den Autor und den Titel, wenn ein Exemplar erzeugt wird.
     * Changelog: Seiten hinzugef�gt: Beta 1.1.0 - 27.10.2020
     * Changelog: Signatur hinzugef�gt: Beta 2.0.1 - 28.10.2020
     * Changelog: Ausgeliehen hinzugef�gt: Beta 2.1.1 - 28.10.2020
     * Changelog: Ausleihzeit hinzugef�gt: Beta 2.1.2 - 28.10.2020
     */
    public Buch(String buchautor, String buchtitel, int seitenAnzahl)
    {
        autor = buchautor;
        titel = buchtitel;
        seiten = seitenAnzahl;
        signatur = "";
        ausgeliehen = 0;
        ausleihzeit = 3;
    }

    /**
     * Getter Methode f�r den Autor
     * Eingef�hrt in Beta 1.0.1 - 27.10.2020
     */
    public String gibAutor()
    {
        return autor;
    }

    /**
     * Getter Methode f�r den Titel
     * Eingef�hrt in Beta 1.0.1 - 27.10.2020
     */
    public String gibTitel()
    {
        return titel;
    }

    /**
     * Getter Methode f�r die Seiten
     * Eingef�hrt in Beta 1.1.0 . 27.10.2020
     */
    public int gibSeiten()
    {
        return seiten;
    }

    /**
     * Getter Methode f�r die Signatur
     * Eingef�hrt in Beta 2.0.1 - 28.10.2020
     */
    public String gibSignatur()
    {
        return signatur;
    }

    /**
     * Ausleihzeit geben
     * Eingef�hrt in Beta 2.2.1 - 28.10.2020
     */
    public int gibAusleihzeit()
    {
        return ausleihzeit;
    }

    /**
     * Setter Methode f�r den Autor
     * Eingef�hrt in Beta 1.0.2 - 27.10.2020
     */
    public void setzeAutor(String neuerAutor)
    {
        autor = neuerAutor;
    }

    /**
     * Setter Methode f�r die Seiten
     * Eingef�hrt in Beta 1.1.0 . 27.10.2020
     */
    public void setzeSeiten(int neueSeitenAnzahl)
    {
        seiten = neueSeitenAnzahl;
    }

    /**
     * Setter Methode f�r den Titel
     * Eingef�hrt in Beta 1.0.2 - 27.10.2020
     */
    public void setzeTitel(String neuerTitel)
    {
        titel = neuerTitel;
    }

    /**
     * Setter Methode f�r die Signatur
     * Eingef�hrt in Beta 2.0.1 - 28.10.2020
     */
    public void setzeSignatur(String neueSignatur)
    {
        if(neueSignatur.length() > 10)
        {
            System.out.println("Signatur konnte nicht gesetzt werden, da die Zeichenl�nge von 10 �berschritten wurde!");
        }
        else
        {
            signatur = neueSignatur;
        }
    }

    /**
     * Ausleizeit setzen
     * Eingef�hrt in Beta 2.2.1 - 28.10.2020
     */
    public void setzeAusleihzeit(int neueAusleihzeit)
    {
        ausleihzeit = neueAusleihzeit;
    }

    /**
     * Ausleihen
     * Eingef�hrt in Beta 2.2.1 - 28.10.2020
     */
    public void ausleihen()
    {
        ausgeliehen++;
    }

    /**
     * Detailausgabe: gibt alle Details auf der Konsole aus
     * Eingef�hrt in Beta 1.1.2 - 27.10.2020
     */
    public void detailausgabe()
    {
        System.out.println("############################################");
        System.out.println("#Im System sind folgende Daten Gespeichert:");
        System.out.println("#Titel: " + titel);
        System.out.println("#Autor: " + autor);
        System.out.println("#Seitenanzahl: " + seiten);
        if(signatur == "")
        {
            System.out.println("#Signatur: Unbekannt");
        }
        else
        {
            System.out.println("#Signatur: " + signatur);
        }
        System.out.println("#Ausgeliehen: " + ausgeliehen +"mal");
        if (ausleihzeit == 0)
        {
            System.out.println("#Ausleihhinweis: Keine Ausleihe m�glich!");
        }
        else
        {
            if (ausleihzeit == 1)
            {
                System.out.println("#Ausleihhinweis: Ausleihe �bers Wochenende!");
            }
            else
            {
                if (ausleihzeit == 2)
                {
                    System.out.println("#Ausleihhinweis: Ausleihe f�r 7 Tage!");
                }
                else
                {
                    if (ausleihzeit == 3)
                    {
                        System.out.println("#Ausleihhinweis: Ausleihe beliebig lange m�glich!");
                    }
                    else
                    {
                        System.out.println("#Fehlerhafter Ausleihzeitcode. Bitte neu setzen!");
                    }
                }
            }
        }
        System.out.println("############################################");
    }
}