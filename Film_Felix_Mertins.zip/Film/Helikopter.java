
/**
 * Beschreiben Sie hier die Klasse Helikopter.
 * 
 * @author (Felix Mertins) 
 * @version (Stable 1.0)
 */
public class Helikopter
{
    private Oval koerper;
    private Rechteck heck;
    private Rechteck rotoru;
    private Rechteck rotor;
    private Quadrat fenster;
    private Quadrat fenster2;
    private Rechteck seil;
    private int alpha;
    /**
     * Konstruktor f�r Objekte der Klasse Helikopter
     */
    public Helikopter()
    {
        koerper = new Oval();
        koerper.XgroesseAendern(100);
        koerper.YgroesseAendern(50);
        koerper.xSetzen(520);
        koerper.ySetzen(60);
        koerper.farbeAendern("rot");

        heck = new Rechteck();
        heck.breiteAendern(100);
        heck.hoeheAendern(5);
        heck.xSetzen(580);
        heck.ySetzen(80);
        heck.farbeAendern("rot");

        rotoru = new Rechteck();
        rotoru.breiteAendern(5);
        rotoru.hoeheAendern(60);
        rotoru.xSetzen(580);
        rotoru.ySetzen(50);
        rotoru.farbeAendern("rot");

        rotor = new Rechteck();
        rotor.breiteAendern(150);
        rotor.hoeheAendern(5);
        rotor.xSetzen(520);
        rotor.ySetzen(50);
        rotor.farbeAendern("rot");

        fenster = new Quadrat();
        fenster.groesseAendern(15);
        fenster.xSetzen(540);
        fenster.ySetzen(70);
        fenster.farbeAendern("gelb");

        fenster2 = new Quadrat();
        fenster2.groesseAendern(20);
        fenster2.xSetzen(580);
        fenster2.ySetzen(70);
        fenster2.farbeAendern("gelb");

        seil = new Rechteck();
        seil.breiteAendern(5);
        seil.hoeheAendern(1);
        seil.xSetzen(560);
        seil.ySetzen(110);
        seil.farbeAendern("schwarz");

    }

    public void zeichne()
    {
        koerper.sichtbarMachen();
        heck.sichtbarMachen();
        rotoru.sichtbarMachen();
        rotor.sichtbarMachen();
        fenster.sichtbarMachen();
        fenster2.sichtbarMachen();
        seil.sichtbarMachen();
    }

    public void zuAuto()
    {
        for(int i = 115;i>0;i--)
        {
            koerper.horizontalBewegen(-3);
            heck.horizontalBewegen(-3);
            rotoru.horizontalBewegen(-3);
            rotor.horizontalBewegen(-3);
            fenster.horizontalBewegen(-3);
            fenster2.horizontalBewegen(-3);
            seil.horizontalBewegen(-3);
        }
    }

    public void seilRunter()
    {
        for(alpha = 1;alpha != 125;alpha++)
        {
            seil.hoeheAendern(alpha);
        }
    }

    public void seilHoch()
    {
        seil.hoeheAendern(alpha--);
    }

    public void heliBewegen()
    {
        koerper.horizontalBewegen(-3);
        heck.horizontalBewegen(-3);
        rotoru.horizontalBewegen(-3);
        rotor.horizontalBewegen(-3);
        fenster.horizontalBewegen(-3);
        fenster2.horizontalBewegen(-3);
        seil.horizontalBewegen(-3);
    }
}
