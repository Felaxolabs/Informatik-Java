/**
 * Diese Klasse definiert eine einfache Zeichnung. Um die Zeichnung auf
 * dem Bildschirm anzeigen zu lassen, muss die zeichne-Operation auf
 * einem Exemplar aufgerufen werden.
 * Aber hier steckt mehr drin: Da es eine elektronische Zeichnung ist,
 * kann sie ge�ndert werden. Man kann sie schwarz-wei� anzeigen lassen
 * und dann wieder in Farbe (nachdem sie gezeichnet wurde, ist ja klar).
 * 
 * Diese Klasse ist als fr�hes Java-Lehrbeispiel mit BlueJ gedacht.
 * 
 * @author  Michael K�lling und David J. Barnes
 * @changes Felix Mertins
 * @version 2.0  (3. September 2020)
 */
public class Zeichnung
{
    //Objektdeklaration

    private Quadrat wand;
    private Quadrat fenster;
    private Dreieck dach;
    private Kreis sonne;
    private Rechteck tuer;
    private Oval wolke1;
    private Oval wolke2;
    private Oval tropfen1;
    private int regen;
    private Kreis mond;
    private Auto1 auto1;
    private Auto2 auto2;
    private Rechteck strasse;
    private Helikopter heli;
    /**
     * Attributmodifikation der verschiedenen Objekte im Bezug auf Farbe, Position und Gr��e
     */
    public Zeichnung()
    {
        // Angaben f�r die Zeichnung

        wand = new Quadrat();
        wand.vertikalBewegen(80);
        wand.groesseAendern(100);

        fenster = new Quadrat();
        fenster.farbeAendern("gelb");
        fenster.horizontalBewegen(20);
        fenster.vertikalBewegen(100);

        dach = new Dreieck();  
        dach.groesseAendern(50, 140);
        dach.horizontalBewegen(60);
        dach.vertikalBewegen(70);
        dach.farbeAendern("rot");

        sonne = new Kreis();
        sonne.farbeAendern("gelb");
        sonne.horizontalBewegen(180);
        sonne.vertikalBewegen(-10);
        sonne.groesseAendern(60);

        tuer = new Rechteck();
        tuer.farbeAendern("gelb");
        tuer.horizontalBewegen(60);
        tuer.vertikalBewegen(120);

        wolke1 = new Oval();
        wolke1.vertikalBewegen(-10);
        wolke1.YgroesseAendern(30);
        wolke1.XgroesseAendern(75);
        wolke1.horizontalBewegen(100);
        wolke1.farbeAendern("blau");

        wolke2 = new Oval();
        wolke2.vertikalBewegen(-10);
        wolke2.YgroesseAendern(20);
        wolke2.XgroesseAendern(50);
        wolke2.horizontalBewegen(50);
        wolke2.farbeAendern("blau");

        tropfen1 = new Oval();
        tropfen1.horizontalBewegen(50);
        tropfen1.vertikalBewegen(-10);
        tropfen1.YgroesseAendern(20);
        tropfen1.XgroesseAendern(10);

        mond = new Kreis();
        mond.farbeAendern("blau");
        mond.groesseAendern(60);
        mond.vertikalBewegen(150);
        mond.horizontalBewegen(30);

        auto1 = new Auto1();

        auto2 = new Auto2();

        strasse = new Rechteck();
        strasse.farbeAendern("schwarz");
        strasse.breiteAendern(600);
        strasse.hoeheAendern(100);
        strasse.vertikalBewegen(250);
        strasse.horizontalBewegen(-100);

        heli = new Helikopter();

    }
    /**
     * Grundmethoden
     */
    /**
     * Zeichnen der Zeichnung.
     */
    public void zeichne()
    {
        //Zeichnen der einzelnen Objekte

        wand.sichtbarMachen();
        fenster.sichtbarMachen();
        dach.sichtbarMachen();
        sonne.sichtbarMachen();
        tuer.sichtbarMachen();
        wolke1.sichtbarMachen();
        wolke2.sichtbarMachen();
        strasse.sichtbarMachen();
        auto1.zeichneAuto1();
        auto2.zeichneAuto2();
    }
    /**
     * Displaymethoden
     */
    /**
     * �ndere die Darstellung in schwarz-wei�.
     */
    public void inSchwarzWeissAendern()
    {
        if(wand != null)   // �berpr�fung ob die Zeichnung schon gezeichnet wurde.
        {
            wand.farbeAendern("schwarz");
            fenster.farbeAendern("weiss");
            dach.farbeAendern("schwarz");
            sonne.farbeAendern("schwarz");
            tuer.farbeAendern("weiss");
            wolke1.farbeAendern("schwarz");
            wolke2.farbeAendern("schwarz");
            tropfen1.farbeAendern("schwarz");
            mond.farbeAendern("schwarz");
        }
        else
        {
            this.zeichne();
            wand.farbeAendern("schwarz");
            fenster.farbeAendern("weiss");
            dach.farbeAendern("schwarz");
            sonne.farbeAendern("schwarz");
            tuer.farbeAendern("weiss");
            wolke1.farbeAendern("schwarz");
            wolke2.farbeAendern("schwarz");
            tropfen1.farbeAendern("schwarz");
            mond.farbeAendern("schwarz");
        }
    }

    /**
     * �ndere die Darstellung in Farbe.
     */
    public void inFarbeAendern()
    {
        if(wand != null)   // �berpr�fung ob die Zeichnung schon gezeichnet wurde.
        {
            wand.farbeAendern("rot");
            fenster.farbeAendern("gelb");
            dach.farbeAendern("gruen");
            sonne.farbeAendern("gelb");
            tuer.farbeAendern("gelb");
            wolke1.farbeAendern("blau");
            wolke2.farbeAendern("blau");
            tropfen1.farbeAendern("blau");
            mond.farbeAendern("blau");
        }
        else
        {
            this.zeichne();
            wand.farbeAendern("rot");
            fenster.farbeAendern("gelb");
            dach.farbeAendern("gruen");
            sonne.farbeAendern("gelb");
            tuer.farbeAendern("gelb");
            wolke1.farbeAendern("blau");
            wolke2.farbeAendern("blau");
            tropfen1.farbeAendern("blau");
            mond.farbeAendern("blau");
        }
    }
    /**
     * Wetter
     */
    /**
     * Sonnen Untergang und Mond Aufgang
     */
    public void sonnenUntergang()
    {   
        if(wand != null)
        {
            mond.xSetzen(50);
            mond.ySetzen(210);
            mond.sichtbarMachen();
            for(int i=150;i>0;i--)
            {
                sonne.vertikalBewegen(1);
                sonne.horizontalBewegen(1);
                mond.vertikalBewegen(-1);
                mond.horizontalBewegen(1);
            }
            this.inSchwarzWeissAendern();
            sonne.unsichtbarMachen();
        }
        else
        {
            this.zeichne();
            mond.xSetzen(50);
            mond.ySetzen(210);
            mond.sichtbarMachen();
            for(int i=150;i>0;i--)
            {
                sonne.vertikalBewegen(1);
                sonne.horizontalBewegen(1);
                mond.vertikalBewegen(-1);
                mond.horizontalBewegen(1);
            }
            this.inSchwarzWeissAendern();
            sonne.unsichtbarMachen();
        }
    }

    public void sonnenAufgang()
    {   
        if(wand != null)
        {
            sonne.sichtbarMachen();
            sonne.horizontalBewegen(-300);
            this.inFarbeAendern();
            for(int i=150;i>0;i--)
            {
                sonne.vertikalBewegen(-1);
                sonne.horizontalBewegen(1);
                mond.vertikalBewegen(1);
                mond.horizontalBewegen(1);
            }
            mond.unsichtbarMachen();
        }
        else
        {
            this.zeichne();
            sonne.horizontalBewegen(-300);
            sonne.sichtbarMachen();
            this.inFarbeAendern();
            for(int i=150;i>0;i--)
            {
                sonne.vertikalBewegen(-1);
                sonne.horizontalBewegen(1);
                mond.vertikalBewegen(1);
                mond.horizontalBewegen(1);
            }
            mond.unsichtbarMachen();
        } 
    }

    public void regne()
    {
        if(wand != null)
        {
            regen =0;
            while(regen < 100)
            {
                tropfen1.langsamVertikalBewegen(150);
                tropfen1.unsichtbarMachen();
                tropfen1.vertikalBewegen(-150);
                tropfen1.sichtbarMachen();
                regen++ ;
            }
            tropfen1.unsichtbarMachen();
        }
        else
        {
            this.zeichne();
            regen =100;
            while(regen > 0 )
            {
                tropfen1.langsamVertikalBewegen(150);
                tropfen1.unsichtbarMachen();
                tropfen1.vertikalBewegen(-150);
                tropfen1.sichtbarMachen();
                regen-- ;
            }
            tropfen1.unsichtbarMachen();
        }
    }
    /**
     * Objektmethoden
     */
    /**
     * AutoUnfall
     */
    public void autoUnfall()
    {
        for(int i=65;i>0;i--)
        {
            auto1.auto1bewegen();
            auto2.auto2bewegen();
        }
    }

    /**
     * Helikopter 
     */
    public void heli()
    {
        heli.zeichne();
        heli.zuAuto();
        heli.seilRunter();
        for(int i = 100;i>0;i--)
        {
            heli.seilHoch();
            auto2.autoHoch();
        }
        for(int i = 200;i>0;i--)
        {
            auto2.auto2SchnellBewegen();
            heli.heliBewegen();
        }
    }
    /**
     * Film
     */
    /**
     * Startet den Film
     */
    public void film()
    {
        this.zeichne();
        this.autoUnfall();
        this.heli();
        
    }
}